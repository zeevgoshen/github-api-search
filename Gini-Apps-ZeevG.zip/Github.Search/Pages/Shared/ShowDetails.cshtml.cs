using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Github.Search.Pages
{
    public class ShowDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
